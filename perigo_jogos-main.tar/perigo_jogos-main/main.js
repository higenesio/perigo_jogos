const botoes=document.querySelectorAll(botoes)
console.log(botoes)